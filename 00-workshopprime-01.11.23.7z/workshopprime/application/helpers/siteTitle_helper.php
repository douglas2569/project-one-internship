<?php
function siteTitle($name='Carlitos Officina'){
    
    return $name;
}