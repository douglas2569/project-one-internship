import {showSandwichMenu, showAccordionMaintenance} from './lib/index.js'

showSandwichMenu()
showAccordionMaintenance()